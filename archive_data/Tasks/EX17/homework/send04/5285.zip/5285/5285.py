'''(№ 5285) (И. Кушнир) В файле 17-336.txt содержится последовательность целых чисел. Элементы последовательности могут
принимать целые значения от 1 до 100 000 включительно. Обозначим через M минимальный элемент последовательности, кратный
 8, но не равный 8. Определите количество пар элементов последовательности, в которых оба числа делятся на M. Гарантируется,
  что такая пара в последовательности есть. В ответе запишите количество найденных пар, затем максимальное из чисел в такой паре с
   минимальной суммой элементов. Если пар с минимальной суммой элементов несколько, то следует выбрать максимальное число из первой
    подходящей пары. В данной задаче под парой подразумевается два идущих подряд элемента последовательности. '''

m = float('inf')
sp = list()
with open("File") as file:
    line = file.readline().strip()
    while line!= "":
        line = int(line)
        if line % 8  == 0 and line != 8 and line<m:
            m = line



        sp.append(int(line))
        line = file.readline().strip()

maxel = -float("inf")
minel = float("inf")

kolvo = 0
test = list()
for i in range( len(sp) -1):


    if sp[i] % m == 0 and sp[i + 1] % m == 0:
        kolvo +=1
        maxx = max(sp[i:i + 1] )

        print(sp[i] , sp[i + 1] )

        spis = []
        for i in str(maxx):
            spis.append(int(i))


        minn  = sum(spis)


        if  minn < minel:
            if maxx > maxel:
                maxel = maxx
                minel = minn




print(kolvo,maxel)

print("Где ошибка?")