lines = list()

SUPER = -float("inf")
lines = list()
with open("17.txt") as file:
    line = file.readline().strip()
    while line != "":
        intline = int(line)
        lines.append(intline)
        if line[-3::] == "121":
            if intline > SUPER:
                SUPER = intline

        line = file.readline().strip()

def del2(num):
    if num % 2 ==0:
        return 1
    return 0
def interestingcalc(lines1,lines2,lines3):
    if len(str(lines1)) + len(str(lines2)) + len(str(lines3)) <= 10:
        if del2(lines1) +del2(lines2) + del2(lines3) <=1:
            return True
    return False



summs = list()

for i in range(0,len(lines)-2):
    summ = lines[i] + lines[i+ 1  ] + lines[i+ 2  ]
    if summ <= SUPER:
        if interestingcalc(lines[i] , lines[i+ 1  ] , lines[i+ 2  ]):
            summs.append(summ)
print(len(summs),max(summs))





