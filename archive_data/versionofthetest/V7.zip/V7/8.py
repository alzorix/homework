A = 0
for i in range(100_000,100_000_000,5):
    i = str(i)
    if ("00" not in i) and ("55" not in i):
        A +=1
print(A)