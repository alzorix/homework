print("* 16 **    +".join("x1x"))
print("* 3 **    +".join("x3x3"))


def ThisTwo(two):
    while two % 2 == 0:
        two = two  //2
    if two ==1:
        return True
    return False
TwoList = list()



for i in range(0,9999):
    TwoList.append(2**i)
print(len(TwoList))


for x in range(0,9999):
    R = x* 16 ** 2   +1* 16 **   1 +x + x* 3 **  3  +3* 3 **  2  +x* 3 **   1 +3
    if ThisTwo(R):
        print(R)
    if R in TwoList:
        print(R)

# В чем проблема?