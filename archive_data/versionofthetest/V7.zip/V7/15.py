from math import  sqrt

def NOD(n,m,k):

    n1 = int(sqrt(n))
    nmax = 0
    for i in range(n1+1,0,-1):
        if n % i == 0:
            nmax = i
        break
    m1 = int(sqrt(m))
    mmax = 0
    for i in range(m1+1,0,-1):
        if m % i == 0:
            mmax = i
        break

    if nmax == 0 or mmax == 0:
        return False
    if nmax == mmax and nmax == k:
        return True
    return False

goods = 0
for A in range(1,1001):
    REDFLAG = True
    for x in range(1,999):
        if NOD(     A,420,2       ) or (not(NOD(  A,x,12        ))) >= (not (NOD(   110,x,11     ))):
            None
        else:
            REDFLAG = False

    if REDFLAG == True:
        goods +=1
print(goods)