with open("26.txt") as fl:
    line = fl.readline().strip()





    while line != 0:
        None
##Нет идей по решению