F = list()
with open("24.txt") as file:
    line = file.readline().strip()
    good_line = ""
    red_flag_count = 0
    for i in line:
        try:
            a = eval(good_line + i)
            good_line = good_line + i
            F.append(len(good_line))

        except:
            if i !="0":
                red_flag_count +=1
            else:
                red_flag_count = 0
                good_line = ""
            if red_flag_count >1:
                red_flag_count = 0
                good_line = ""
print(max(F))
#10